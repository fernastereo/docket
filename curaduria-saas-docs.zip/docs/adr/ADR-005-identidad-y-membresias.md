# ADR-005: Identidad centralizada, membresía y autorización por tenant

**Estado**: Aceptada
**Fecha**: 2026-07-21

## Contexto

Usuarios del sistema: empleados de curaduría (radicadores, revisores, curador,
etc.) y ciudadanos solicitantes. Un ciudadano puede radicar trámites en varias
curadurías. No hay hoy empleados que trabajen para más de una curaduría, pero
el modelo no debe impedirlo. El aislamiento de datos de negocio por tenant es
innegociable (ADR-002).

## Decisión

Separar **identidad** de **membresía**:

- **Identidad (base central)**: una cuenta única por persona — email, contraseña,
  nombre, **documento de identidad (llave natural única)**, teléfono. Aplica a
  ciudadanos y empleados por igual. Identificador técnico: **UUID**.
  Flag de plataforma para usuarios de soporte/superadmin del proveedor.
- **Membresía y autorización (base de cada tenant)**: tabla de miembros que
  referencia a la identidad por UUID (sin FK física, es otra base) y define el
  rol dentro de esa curaduría (radicador, revisor técnico, revisor jurídico,
  curador, etc.). El RBAC completo vive en el tenant.
- **Ciudadanos**: una sola cuenta; acceden por el subdominio de la curaduría de
  interés. Sus expedientes en cada curaduría son independientes y viven en la
  base de cada tenant.
- **Datos personales mínimos en la central**: solo lo necesario para
  autenticar/identificar. Los datos del solicitante en contexto de trámite
  (dirección, calidad en que actúa, etc.) viven en el expediente del tenant.
- **Personas jurídicas**: la identidad siempre es una persona natural; el
  expediente registra en calidad de qué actúa (propietario, apoderado,
  representante legal de empresa con NIT). El modelo debe permitir a futuro
  varios usuarios asociados a una misma empresa.

## Reglas de privacidad entre tenants

- Al buscar por cédula desde ventanilla, la central responde únicamente si la
  identidad existe y sus datos básicos. **Nunca** revela en qué otras
  curadurías tiene trámites o membresías.

## Consecuencias

- Audit log del tenant registra "UUID-X con rol Y hizo Z"; para que la base
  entregada en offboarding sea legible, el export incluye un snapshot de los
  datos básicos de las identidades referenciadas.
- Colisiones de identidad (mismo documento, email distinto) se resuelven por
  flujo de recuperación/verificación, nunca creando cuenta duplicada.
